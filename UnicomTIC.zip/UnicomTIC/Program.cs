using System;
using System.Windows.Forms;
using UnicornTICManagementSystem.Views;

namespace UnicornTICManagementSystem
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            DatabaseManager.InitializeDatabase();
            Application.EnableVisualStyles();
            ApplicationConfiguration.Initialize();
            Application.Run(new LoginForm());
        }
    }
}