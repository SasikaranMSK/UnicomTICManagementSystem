using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnicornTICManagementSystem.Models;
using UnicornTICManagementSystem.Repositories;

namespace UnicornTICManagementSystem.Controllers
{
    public class MarkController
    {
        private readonly DatabaseManager _databaseManager;

        public MarkController()
        {
            _databaseManager = new DatabaseManager();
        }

        public async Task<List<Mark>> GetMarksByStudentAsync(int studentId)
        {
            return await _databaseManager.GetMarksByStudentAsync(studentId);
        }

        public async Task<List<Mark>> GetMarksByCourseAsync(int courseId)
        {
            return await _databaseManager.GetMarksByCourseAsync(courseId);
        }

        public async Task<bool> AddMarkAsync(Mark mark)
        {
            try
            {
                mark.Grade = CalculateGrade(mark.Percentage);
                return await _databaseManager.AddMarkAsync(mark);
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to add mark: {ex.Message}");
            }
        }

        public async Task<bool> UpdateMarkAsync(Mark mark)
        {
            try
            {
                mark.Grade = CalculateGrade(mark.Percentage);
                return await _databaseManager.UpdateMarkAsync(mark);
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to update mark: {ex.Message}");
            }
        }

        private string CalculateGrade(decimal percentage)
        {
            return percentage switch
            {
                >= 90 => "A+",
                >= 85 => "A",
                >= 80 => "A-",
                >= 75 => "B+",
                >= 70 => "B",
                >= 65 => "B-",
                >= 60 => "C+",
                >= 55 => "C",
                >= 50 => "C-",
                _ => "F"
            };
        }

        public bool ValidateMark(Mark mark)
        {
            return mark.StudentId > 0 &&
                   mark.ExamId > 0 &&
                   mark.MarksObtained >= 0 &&
                   mark.MarksObtained <= mark.MaxMarks;
        }
    }
}