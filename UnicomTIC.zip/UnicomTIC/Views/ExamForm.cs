using System;
using System.Drawing;
using System.Windows.Forms;
using UnicornTICManagementSystem.Controllers;

namespace UnicornTICManagementSystem.Views
{
    public partial class ExamForm : Form
    {
        private readonly ExamController _examController;
        private DataGridView dgvExams;
        private Button btnAdd;
        private Button btnEdit;
        private Button btnDelete;
        private Button btnRefresh;

        public ExamForm()
        {
            _examController = new ExamController();
            InitializeComponent();
            LoadExams();
        }

        private void InitializeComponent()
        {
            this.Text = "Exam Management";
            this.Size = new Size(1000, 600);
            this.StartPosition = FormStartPosition.CenterParent;

            // Buttons
            btnAdd = new Button();
            btnAdd.Text = "Add Exam";
            btnAdd.Location = new Point(20, 15);
            btnAdd.Size = new Size(100, 30);
            btnAdd.BackColor = Color.LightGreen;
            btnAdd.Click += BtnAdd_Click;
            this.Controls.Add(btnAdd);

            btnEdit = new Button();
            btnEdit.Text = "Edit Exam";
            btnEdit.Location = new Point(130, 15);
            btnEdit.Size = new Size(100, 30);
            btnEdit.BackColor = Color.LightBlue;
            btnEdit.Click += BtnEdit_Click;
            this.Controls.Add(btnEdit);

            btnDelete = new Button();
            btnDelete.Text = "Delete Exam";
            btnDelete.Location = new Point(240, 15);
            btnDelete.Size = new Size(100, 30);
            btnDelete.BackColor = Color.LightCoral;
            btnDelete.Click += BtnDelete_Click;
            this.Controls.Add(btnDelete);

            btnRefresh = new Button();
            btnRefresh.Text = "Refresh";
            btnRefresh.Location = new Point(350, 15);
            btnRefresh.Size = new Size(80, 30);
            btnRefresh.Click += BtnRefresh_Click;
            this.Controls.Add(btnRefresh);

            // DataGridView
            dgvExams = new DataGridView();
            dgvExams.Location = new Point(20, 60);
            dgvExams.Size = new Size(950, 500);
            dgvExams.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvExams.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvExams.MultiSelect = false;
            dgvExams.ReadOnly = true;
            dgvExams.AllowUserToAddRows = false;
            this.Controls.Add(dgvExams);
        }

        private async void LoadExams()
        {
            try
            {
                var exams = await _examController.GetAllExamsAsync();
                dgvExams.DataSource = exams;

                // Hide unnecessary columns
                if (dgvExams.Columns["Id"] != null)
                    dgvExams.Columns["Id"].Visible = false;
                if (dgvExams.Columns["CourseId"] != null)
                    dgvExams.Columns["CourseId"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading exams: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Add Exam functionality will be implemented here.", "Info",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Edit Exam functionality will be implemented here.", "Info",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Delete Exam functionality will be implemented here.", "Info",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            LoadExams();
        }
    }
}